import {
  CanActivate,
  ExecutionContext,
  Injectable,
  SetMetadata,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthGuard } from '@nestjs/passport';
import { IS_PUBLIC_KEY } from './auth.decorators';

export const Permissions = (...perms: string[]) => SetMetadata('permissions', perms);

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  constructor(private reflector: Reflector) {
    super();
  }

  canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;
    return super.canActivate(context);
  }

  handleRequest<T>(err: Error | null, user: T) {
    if (err || !user) throw err ?? new UnauthorizedException();
    return user;
  }
}

function permissionMatches(owned: string, required: string): boolean {
  if (owned === '*') return true;
  if (owned === required) return true;
  if (owned.endsWith(':*')) return required.startsWith(owned.slice(0, -1));
  return false;
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<string[]>('permissions', [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required?.length) return true;

    const req = context.switchToHttp().getRequest<{ user?: { permissions?: string[] } }>();
    const perms = req.user?.permissions ?? [];
    const ok = required.some((needed) => perms.some((owned) => permissionMatches(owned, needed)));
    if (!ok) throw new UnauthorizedException('Insufficient permissions');
    return true;
  }
}
