import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Calculator" description="Calculator module for EnergySavings ROI. Includes realistic cards, tables, actions and frontend states." />;
}
