$ErrorActionPreference = "Stop"
Write-Host "Building HR Command Admin..." -ForegroundColor Cyan
if (!(Test-Path "node_modules")) { npm install }
npm run build
