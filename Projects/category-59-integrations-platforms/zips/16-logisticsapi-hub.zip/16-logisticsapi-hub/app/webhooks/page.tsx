import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Webhooks" description="Webhooks module for LogisticsAPI Hub. Includes realistic cards, tables, actions and frontend states." />;
}
