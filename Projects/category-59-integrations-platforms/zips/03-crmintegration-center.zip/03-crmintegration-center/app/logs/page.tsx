import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Logs" description="Logs module for CRMIntegration Center. Includes realistic cards, tables, actions and frontend states." />;
}
