import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Auth Config" description="Auth Config module for WebhookOps Console. Includes realistic cards, tables, actions and frontend states." />;
}
