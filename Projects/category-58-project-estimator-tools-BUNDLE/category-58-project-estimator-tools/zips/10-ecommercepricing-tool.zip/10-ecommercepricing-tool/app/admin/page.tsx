import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Admin" description="Admin module for EcommercePricing Tool. Includes realistic cards, tables, actions and frontend states." />;
}
