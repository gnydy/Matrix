import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Roadmap" description="Roadmap module for ReleasePlanner Board. Includes realistic cards, tables, actions and frontend states." />;
}
