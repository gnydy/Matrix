import '../styles/globals.css';
export const metadata = { title: 'BrandBook Executive', description: 'Brand guidelines, logo systems, typography, colors, and case studies' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
