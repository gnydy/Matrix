import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Settings" description="Settings module for FeatureTrial Hub. Includes realistic cards, tables, actions and frontend states." />;
}
