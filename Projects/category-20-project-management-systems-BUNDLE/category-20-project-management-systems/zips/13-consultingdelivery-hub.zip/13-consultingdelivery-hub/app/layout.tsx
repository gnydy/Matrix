import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'ConsultingDelivery Hub',
  description: 'Consulting engagement delivery dashboard.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
