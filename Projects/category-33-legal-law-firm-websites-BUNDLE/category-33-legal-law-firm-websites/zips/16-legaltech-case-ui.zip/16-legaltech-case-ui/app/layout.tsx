import '../styles/globals.css';
export const metadata = { title: 'LegalTech Case UI', description: 'Law firm sites, consultation booking, legal articles, cases, and teams' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
