# Arbitration Center

Category: 33 - Legal & Law Firm Websites

## Description
Law firm sites, consultation booking, legal articles, cases, and teams. This template uses a distinct UI pattern: split command layout with sticky right insight panel.

## Tech
Next.js, TypeScript, Tailwind CSS, API Routes, Mock Data.

## Install
```powershell
npm install --include=optional --legacy-peer-deps --no-audit --no-fund
```

## Run
```powershell
npm run dev -- -p 3001
```

## API Mock
- `/api/health`
- `/api/records`

## Client Notes
Frontend and backend mock only. Production requires database, authentication, permissions, validation, audit logs, deployment hardening, and real integrations.
