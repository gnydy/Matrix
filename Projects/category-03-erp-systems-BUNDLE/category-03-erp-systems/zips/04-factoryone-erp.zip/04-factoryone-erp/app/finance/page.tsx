import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Finance" description="Finance module for FactoryOne ERP. Includes realistic cards, tables, actions and frontend states." />;
}
