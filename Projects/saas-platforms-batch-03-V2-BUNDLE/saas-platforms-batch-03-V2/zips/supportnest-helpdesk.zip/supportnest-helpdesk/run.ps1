$ErrorActionPreference = "Stop"
Set-Location "$PSScriptRoot"
npm install
npm run dev -- --port 3044
