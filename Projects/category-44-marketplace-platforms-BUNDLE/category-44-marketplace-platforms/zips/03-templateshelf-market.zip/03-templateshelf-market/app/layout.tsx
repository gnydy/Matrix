import '../styles/globals.css';
export const metadata = { title: 'TemplateShelf Market', description: 'Vendor listings, products, services, orders, reviews, seller/buyer dashboards' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
