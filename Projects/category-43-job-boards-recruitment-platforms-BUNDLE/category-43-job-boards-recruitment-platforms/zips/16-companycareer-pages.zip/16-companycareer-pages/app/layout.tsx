import '../styles/globals.css';
export const metadata = { title: 'CompanyCareer Pages', description: 'Job listings, applications, candidate profiles, company pages, and recruiter dashboards' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
