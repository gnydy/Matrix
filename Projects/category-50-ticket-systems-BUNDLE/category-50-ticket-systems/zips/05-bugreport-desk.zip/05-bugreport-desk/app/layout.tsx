import '../styles/globals.css';
export const metadata = { title: 'BugReport Desk', description: 'Ticket lists, priorities, agents, SLA, replies, statuses, and escalation UI' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
