import '../styles/globals.css';
export const metadata = { title: 'FitOut Pro Builders', description: 'Projects, equipment, safety, services, galleries, and contracting portfolios' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
