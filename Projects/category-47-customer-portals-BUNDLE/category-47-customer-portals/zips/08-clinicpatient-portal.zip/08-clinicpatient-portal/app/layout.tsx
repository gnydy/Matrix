import '../styles/globals.css';
export const metadata = { title: 'ClinicPatient Portal', description: 'Tickets, invoices, files, orders, project status, account settings' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
