import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Pricing" description="Pricing module for SoftwareQuote Builder. Includes realistic cards, tables, actions and frontend states." />;
}
