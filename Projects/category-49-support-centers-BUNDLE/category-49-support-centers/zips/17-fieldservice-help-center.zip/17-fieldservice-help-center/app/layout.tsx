import '../styles/globals.css';
export const metadata = { title: 'FieldService Help Center', description: 'Knowledge bases, tickets, FAQs, chat support, contact forms, and status updates' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
