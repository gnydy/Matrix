import '../styles/globals.css';
export const metadata = { title: 'CustomerExperience Lab', description: 'Business strategy, finance, HR, operations, and transformation consulting' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
