import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Status" description="Status module for MaintenanceWindow Page. Includes realistic cards, tables, actions and frontend states." />;
}
