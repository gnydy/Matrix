import '../styles/globals.css';
export const metadata = { title: 'BusinessOps Blog', description: 'Personal, tech, AI, business, finance, and lifestyle blog systems' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
