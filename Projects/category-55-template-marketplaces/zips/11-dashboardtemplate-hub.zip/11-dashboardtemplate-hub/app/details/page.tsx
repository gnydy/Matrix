import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Template Details" description="Template Details module for DashboardTemplate Hub. Includes realistic cards, tables, actions and frontend states." />;
}
