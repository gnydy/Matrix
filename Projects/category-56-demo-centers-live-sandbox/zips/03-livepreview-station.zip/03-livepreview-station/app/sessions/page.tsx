import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Demo Sessions" description="Demo Sessions module for LivePreview Station. Includes realistic cards, tables, actions and frontend states." />;
}
