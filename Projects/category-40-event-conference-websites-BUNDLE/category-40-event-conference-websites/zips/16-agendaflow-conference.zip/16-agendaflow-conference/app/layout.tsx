import '../styles/globals.css';
export const metadata = { title: 'AgendaFlow Conference', description: 'Speakers, agenda, tickets, sponsors, venues, and registration' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
