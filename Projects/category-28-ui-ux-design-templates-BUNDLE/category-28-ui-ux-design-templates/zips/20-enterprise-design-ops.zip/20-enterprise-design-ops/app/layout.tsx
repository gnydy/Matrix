import '../styles/globals.css';
export const metadata = { title: 'Enterprise Design Ops', description: 'Design systems, component libraries, wireframes, and product screens' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
