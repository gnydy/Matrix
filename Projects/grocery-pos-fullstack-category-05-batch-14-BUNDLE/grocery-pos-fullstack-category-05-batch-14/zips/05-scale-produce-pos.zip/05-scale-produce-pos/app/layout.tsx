import type { Metadata } from 'next';
import './globals.css';
import { Header } from '@/components/Header';

export const metadata: Metadata = {
  title: 'Scale Produce POS | Grocery POS Fullstack Template',
  description: 'وزن بالكيلو، باركود، أسعار متغيرة حسب اليوم',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header />
        {children}
      </body>
    </html>
  );
}
