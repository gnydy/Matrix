import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Demo Gallery" description="Demo Gallery module for TrySystem Center. Includes realistic cards, tables, actions and frontend states." />;
}
