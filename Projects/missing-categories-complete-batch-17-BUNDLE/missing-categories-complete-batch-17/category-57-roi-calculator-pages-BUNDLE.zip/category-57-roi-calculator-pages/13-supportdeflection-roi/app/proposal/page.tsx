import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Proposal" description="Proposal module for SupportDeflection ROI. Includes realistic cards, tables, actions and frontend states." />;
}
