import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Versions" description="Versions module for SDK Documentation. Includes realistic cards, tables, actions and frontend states." />;
}
