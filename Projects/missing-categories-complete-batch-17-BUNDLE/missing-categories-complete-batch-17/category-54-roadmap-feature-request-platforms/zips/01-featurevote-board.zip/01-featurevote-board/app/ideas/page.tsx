import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Feature Requests" description="Feature Requests module for FeatureVote Board. Includes realistic cards, tables, actions and frontend states." />;
}
