import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Changelog" description="Changelog module for MobileFeature Board. Includes realistic cards, tables, actions and frontend states." />;
}
