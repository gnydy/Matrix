import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Logs" description="Logs module for ShopifySync Platform. Includes realistic cards, tables, actions and frontend states." />;
}
