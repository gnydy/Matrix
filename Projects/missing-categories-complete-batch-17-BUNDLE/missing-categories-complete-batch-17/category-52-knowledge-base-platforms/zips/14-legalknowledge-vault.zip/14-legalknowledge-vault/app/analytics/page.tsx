import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Analytics" description="Analytics module for LegalKnowledge Vault. Includes realistic cards, tables, actions and frontend states." />;
}
