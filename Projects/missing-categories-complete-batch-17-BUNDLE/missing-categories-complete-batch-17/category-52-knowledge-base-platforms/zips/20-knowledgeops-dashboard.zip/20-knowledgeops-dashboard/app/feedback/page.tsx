import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Feedback" description="Feedback module for KnowledgeOps Dashboard. Includes realistic cards, tables, actions and frontend states." />;
}
