import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Feature Picker" description="Feature Picker module for ProjectScope Estimator. Includes realistic cards, tables, actions and frontend states." />;
}
