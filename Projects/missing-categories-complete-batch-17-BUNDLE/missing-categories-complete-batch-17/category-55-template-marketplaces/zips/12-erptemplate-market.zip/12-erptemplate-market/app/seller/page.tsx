import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Seller Dashboard" description="Seller Dashboard module for ERPTemplate Market. Includes realistic cards, tables, actions and frontend states." />;
}
