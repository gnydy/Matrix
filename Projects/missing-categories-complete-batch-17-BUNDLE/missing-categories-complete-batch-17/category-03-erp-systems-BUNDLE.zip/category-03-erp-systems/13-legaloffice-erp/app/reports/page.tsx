import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Reports" description="Reports module for LegalOffice ERP. Includes realistic cards, tables, actions and frontend states." />;
}
