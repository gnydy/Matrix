import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Reports" description="Reports module for ConstructionOffice Suite. Includes realistic cards, tables, actions and frontend states." />;
}
