import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Operations" description="Operations module for WarehouseOps Solution. Includes realistic cards, tables, actions and frontend states." />;
}
