import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Solution Home" description="Solution Home module for RealEstateOffice OS. Includes realistic cards, tables, actions and frontend states." />;
}
