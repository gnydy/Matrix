import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Clients" description="Clients module for RetailShop OS. Includes realistic cards, tables, actions and frontend states." />;
}
