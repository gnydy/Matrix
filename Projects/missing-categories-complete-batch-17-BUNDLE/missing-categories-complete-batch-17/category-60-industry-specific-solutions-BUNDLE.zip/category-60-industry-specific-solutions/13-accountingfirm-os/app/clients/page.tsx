import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Clients" description="Clients module for AccountingFirm OS. Includes realistic cards, tables, actions and frontend states." />;
}
