import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Checkout Mock" description="Checkout Mock module for PremiumBlocks Store. Includes realistic cards, tables, actions and frontend states." />;
}
