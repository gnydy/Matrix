import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Licenses" description="Licenses module for PremiumBlocks Store. Includes realistic cards, tables, actions and frontend states." />;
}
