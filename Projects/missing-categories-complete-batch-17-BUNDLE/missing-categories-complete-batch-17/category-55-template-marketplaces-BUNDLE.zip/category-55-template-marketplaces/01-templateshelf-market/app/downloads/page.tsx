import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Downloads" description="Downloads module for TemplateShelf Market. Includes realistic cards, tables, actions and frontend states." />;
}
