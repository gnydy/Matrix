import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Subscribers" description="Subscribers module for SecurityStatus Center. Includes realistic cards, tables, actions and frontend states." />;
}
