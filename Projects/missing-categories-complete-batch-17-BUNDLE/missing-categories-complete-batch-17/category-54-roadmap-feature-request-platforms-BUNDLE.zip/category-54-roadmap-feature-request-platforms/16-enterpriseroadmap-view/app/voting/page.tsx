import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Voting" description="Voting module for EnterpriseRoadmap View. Includes realistic cards, tables, actions and frontend states." />;
}
