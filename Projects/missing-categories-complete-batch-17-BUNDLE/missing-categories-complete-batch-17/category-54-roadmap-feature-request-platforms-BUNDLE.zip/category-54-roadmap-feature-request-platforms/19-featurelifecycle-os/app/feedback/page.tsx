import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Feedback Inbox" description="Feedback Inbox module for FeatureLifecycle OS. Includes realistic cards, tables, actions and frontend states." />;
}
