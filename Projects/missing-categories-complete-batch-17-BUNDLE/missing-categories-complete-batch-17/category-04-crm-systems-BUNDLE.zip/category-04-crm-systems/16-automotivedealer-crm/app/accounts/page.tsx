import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Accounts" description="Accounts module for AutomotiveDealer CRM. Includes realistic cards, tables, actions and frontend states." />;
}
