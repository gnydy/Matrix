# Onboarding Playbook Docs

Category 51: Documentation Websites

## Description
A sellable Next.js template with a differentiated UI concept, realistic frontend screens and backend mock API routes.

## Tech
- Next.js App Router
- TypeScript
- Tailwind CSS
- Component-based architecture
- Mock Data
- API Routes Mock Backend
- PowerShell scripts for Windows

## Pages
- / — Overview
- /docs — Docs Home
- /guides — Guides
- /api-reference — API Reference
- /versions — Versions
- /changelog — Changelog
- /search — Search

## API Routes
- GET /api/health
- GET/POST /api/records
- GET/POST /api/actions

## Run
```powershell
npm install --include=optional --legacy-peer-deps --no-audit --no-fund
npm run dev
```

## Build
```powershell
npm run build
```

## Notes
This is a portfolio and sales template, not a production backend. Add database, authentication, role permissions, audit logs and validation before selling as a real system.
