import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Search" description="Search module for Admin Manual Portal. Includes realistic cards, tables, actions and frontend states." />;
}
