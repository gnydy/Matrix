import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Work Orders" description="Work Orders module for FurnitureFactory Planner. Includes realistic cards, tables, actions and frontend states." />;
}
