import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Materials" description="Materials module for PlantShift Control. Includes realistic cards, tables, actions and frontend states." />;
}
