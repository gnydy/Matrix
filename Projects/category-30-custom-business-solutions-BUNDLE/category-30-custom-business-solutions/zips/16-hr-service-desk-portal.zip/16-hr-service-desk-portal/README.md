# HR Service Desk Portal

Category: 30 - Custom Business Solutions

## Description
Internal portals, operational systems, workflows, and business dashboards. This template uses a distinct UI pattern: data room layout with document table and activity feed.

## Tech
Next.js, TypeScript, Tailwind CSS, API Routes, Mock Data.

## Install
```powershell
npm install --include=optional --legacy-peer-deps --no-audit --no-fund
```

## Run
```powershell
npm run dev -- -p 3001
```

## API Mock
- `/api/health`
- `/api/records`

## Client Notes
Frontend and backend mock only. Production requires database, authentication, permissions, validation, audit logs, deployment hardening, and real integrations.
