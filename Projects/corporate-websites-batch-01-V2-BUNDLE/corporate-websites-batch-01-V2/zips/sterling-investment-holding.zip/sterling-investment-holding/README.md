# Sterling Investment Holding

## Commercial Description
Holding company layout with portfolio allocation, governance, investor report and sector thesis

## Target Client
Investment holding company presenting portfolio, sectors and governance

## Difference From Other Templates
This V2 template has its own UX structure and page composition. It is not a recolor of the other templates.

## Tech
Next.js App Router, TypeScript, Tailwind CSS, component-based structure, mock corporate data, SEO metadata.

## Run
```powershell
npm install
npm run dev -- --port 3015
```

## Build
```powershell
npm run build
```

## ZIP
```powershell
.\zip.ps1
```

## Customization
Edit `data/site.ts` for content, `app/page.tsx` for layout, and Tailwind classes for visual identity.
