$ErrorActionPreference = "Stop"
Set-Location "$PSScriptRoot"
npm install
npm run build
