import '../styles/globals.css';
export const metadata = { title: 'CloudSecurity Command', description: 'SOC dashboards, threat monitoring, compliance, and security services' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
