import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="Guides" description="Guides module for Enterprise Help Docs. Includes realistic cards, tables, actions and frontend states." />;
}
