import ModulePage from '@/components/ModulePage';

export default function Page() {
  return <ModulePage title="API Reference" description="API Reference module for Docs Search Experience. Includes realistic cards, tables, actions and frontend states." />;
}
